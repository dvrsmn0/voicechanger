package com.example.voicechanger

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.*
import android.os.IBinder
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

object VoiceSettings {
    @Volatile var ratio = 1.0f
    @Volatile var robot = false
    @Volatile var running = false
}

class VoiceService : Service() {
    @Volatile private var active = false
    private var thread: Thread? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("vc", "Voice Changer", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "vc")
            .setContentTitle("Voice changer is on")
            .setContentText("Your voice is being changed live")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n)
        if (!active) {
            active = true
            VoiceSettings.running = true
            thread = Thread { loop() }.also { it.priority = Thread.MAX_PRIORITY; it.start() }
        }
        return START_NOT_STICKY
    }

    private fun loop() {
        val sr = 16000
        val inMin = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val outMin = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, max(inMin, 1280))
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sr)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(max(outMin, 1280))
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        val shifter = PitchShifter()
        val chunk = ShortArray(320)
        var t = 0.0
        rec.startRecording(); track.play()
        while (active) {
            val n = rec.read(chunk, 0, chunk.size)
            if (n <= 0) continue
            val ratio = VoiceSettings.ratio
            val robot = VoiceSettings.robot
            for (i in 0 until n) {
                var s = shifter.process(chunk[i] / 32768f, ratio)
                if (robot) { s *= (0.35 + 0.65 * sin(t)).toFloat(); t += 2 * PI * 60 / sr; if (t > 2 * PI) t -= 2 * PI }
                chunk[i] = (s * 32767f).coerceIn(-32768f, 32767f).toInt().toShort()
            }
            track.write(chunk, 0, n)
        }
        rec.stop(); rec.release(); track.stop(); track.release()
    }

    override fun onDestroy() {
        active = false
        VoiceSettings.running = false
        super.onDestroy()
    }
}
