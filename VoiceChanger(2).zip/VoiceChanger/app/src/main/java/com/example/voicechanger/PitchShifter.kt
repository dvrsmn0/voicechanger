package com.example.voicechanger

import kotlin.math.abs
import kotlin.math.floor

/** Low-CPU real-time pitch shifter (two crossfaded delay taps). ratio < 1 = deeper, > 1 = higher. */
class PitchShifter(private val window: Int = 640) {
    private val size = 4096
    private val mask = size - 1
    private val buf = FloatArray(size)
    private var wp = 0
    private var phase = 0f

    private fun read(delay: Float): Float {
        var pos = wp - delay
        if (pos < 0f) pos += size
        val i = floor(pos).toInt()
        val frac = pos - i
        val a = buf[i and mask]
        val b = buf[(i + 1) and mask]
        return a + (b - a) * frac
    }

    fun process(x: Float, ratio: Float): Float {
        buf[wp] = x
        var p2 = phase + 0.5f
        if (p2 >= 1f) p2 -= 1f
        val g1 = 1f - abs(2f * phase - 1f)
        val out = g1 * read(phase * window) + (1f - g1) * read(p2 * window)
        phase += (1f - ratio) / window
        if (phase >= 1f) phase -= 1f
        if (phase < 0f) phase += 1f
        wp = (wp + 1) and mask
        return out
    }
}
