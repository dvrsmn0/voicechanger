package com.example.voicechanger

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import kotlin.math.pow

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var startBtn: Button
    private lateinit var slider: SeekBar
    private lateinit var semiLabel: TextView

    private val presets = listOf(
        Triple("Normal", 0, false), Triple("Male", -5, false), Triple("Deep", -8, false),
        Triple("Female", 5, false), Triple("Child", 8, false), Triple("Robot", 0, true)
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40); setBackgroundColor(Color.parseColor("#12121A"))
        }
        fun tv(t: String, size: Float) = TextView(this).apply { text = t; textSize = size; setTextColor(Color.WHITE) }
        root.addView(tv("Voice Changer", 28f))
        status = tv("Stopped", 16f).apply { setTextColor(Color.parseColor("#9AA0B4")) }
        root.addView(status)

        startBtn = Button(this).apply { text = "START"; setOnClickListener { toggle() } }
        root.addView(startBtn, LinearLayout.LayoutParams(-1, 160).apply { topMargin = 40 })

        val grid = GridLayout(this).apply { columnCount = 3 }
        presets.forEach { (name, semi, robot) ->
            grid.addView(Button(this).apply {
                text = name
                setOnClickListener { slider.progress = semi + 12; VoiceSettings.robot = robot }
            }, GridLayout.LayoutParams().apply { width = 0; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) })
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 40 })

        semiLabel = tv("Pitch: 0", 16f).apply { gravity = Gravity.CENTER }
        root.addView(semiLabel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 40 })
        slider = SeekBar(this).apply {
            max = 24; progress = 12
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    val semi = p - 12
                    semiLabel.text = "Pitch: " + (if (semi > 0) "+" else "") + semi
                    VoiceSettings.ratio = 2.0.pow(semi / 12.0).toFloat()
                    if (u) VoiceSettings.robot = false
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(slider)
        root.addView(tv("Tip: put your call on speaker and keep the volume low to avoid echo.", 13f).apply {
            setTextColor(Color.parseColor("#9AA0B4")); setPadding(0, 40, 0, 0)
        })
        setContentView(root)
        refresh()
    }

    private fun toggle() {
        if (VoiceSettings.running) {
            stopService(Intent(this, VoiceService::class.java))
            VoiceSettings.running = false
        } else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
            }
            startForegroundService(Intent(this, VoiceService::class.java))
            VoiceSettings.running = true
        }
        refresh()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) toggle()
    }

    private fun refresh() {
        status.text = if (VoiceSettings.running) "Live - your voice is being changed" else "Stopped"
        startBtn.text = if (VoiceSettings.running) "STOP" else "START"
    }
}
